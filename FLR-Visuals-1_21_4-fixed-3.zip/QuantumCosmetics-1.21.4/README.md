# FLR Visuals — Minecraft 1.21.1 (NeoForge)

Client-side cosmetic mod. Press **Right Shift** to open the menu.

- Halo, Wings, Cape (visible in third person, only to you)
- Aura and Trail particles, Hit Sparks
- 5 color themes

Build: JDK 21 + Gradle 8.12 -> `gradle build` -> `build/libs/flr-visuals-1.0.0.jar`
Put the jar into `mods/` of a NeoForge 1.21.1 instance.
