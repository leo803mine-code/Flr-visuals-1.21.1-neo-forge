package com.flr.visuals;

import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

@EventBusSubscriber(modid = FlrVisuals.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(FlrKeys.MENU);
    }

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (PlayerSkin.Model model : new PlayerSkin.Model[]{PlayerSkin.Model.WIDE, PlayerSkin.Model.SLIM}) {
            Object renderer = event.getSkin(model);
            if (renderer instanceof PlayerRenderer playerRenderer) {
                playerRenderer.addLayer(new CosmeticsLayer(playerRenderer));
            }
        }
    }
}
