package com.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import org.joml.Matrix4f;

/** Draws halo, wings and cape as flat colored quads (no textures needed). */
public class CosmeticsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    public CosmeticsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int packedLight,
                       AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float age, float netHeadYaw, float headPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (player != mc.player || player.isInvisible()) return;
        if (!Config.halo && !Config.wings && !Config.cape) return;

        VertexConsumer vc = buffers.getBuffer(RenderType.debugQuads());
        Matrix4f m = pose.last().pose();

        int main = Config.color();
        int bright = mix(main, 0xFFFFFF, 0.55f);
        int dark = mix(main, 0x000000, 0.6f);

        if (Config.cape) cape(vc, m, age, limbSwingAmount, main, dark);
        if (Config.wings) wings(vc, m, age, main, bright);
        if (Config.halo) halo(vc, m, age, bright);
    }

    // ---- halo -------------------------------------------------------------

    private static void halo(VertexConsumer vc, Matrix4f m, float age, int color) {
        float y = -0.64f + (float) Math.sin(age * 0.1f) * 0.02f;
        int n = 32;
        int solid = withAlpha(color, 235);
        int glow = withAlpha(color, 70);
        for (int i = 0; i < n; i++) {
            double a0 = i * 2.0 * Math.PI / n;
            double a1 = (i + 1) * 2.0 * Math.PI / n;
            ring(vc, m, a0, a1, 0.20f, 0.33f, y + 0.004f, glow);
            ring(vc, m, a0, a1, 0.23f, 0.30f, y, solid);
        }
    }

    private static void ring(VertexConsumer vc, Matrix4f m, double a0, double a1,
                             float ri, float ro, float y, int color) {
        float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0);
        float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
        quad(vc, m, new int[]{color, color, color, color},
                c0 * ri, y, s0 * ri,
                c0 * ro, y, s0 * ro,
                c1 * ro, y, s1 * ro,
                c1 * ri, y, s1 * ri);
    }

    // ---- cape -------------------------------------------------------------

    private static void cape(VertexConsumer vc, Matrix4f m, float age, float swing, int top, int bottom) {
        int segs = 8;
        float hw = 0.27f, len = 1.0f, y0 = 0.02f, zBase = 0.16f;
        float lift = 0.05f + Math.min(swing, 1.0f) * 0.30f;
        for (int i = 0; i < segs; i++) {
            float t0 = i / (float) segs;
            float t1 = (i + 1) / (float) segs;
            float zA = zBase + capeZ(t0, age, lift);
            float zB = zBase + capeZ(t1, age, lift);
            float yA = y0 + len * t0;
            float yB = y0 + len * t1;
            int cA = withAlpha(mix(top, bottom, t0), 255);
            int cB = withAlpha(mix(top, bottom, t1), 255);
            quad(vc, m, new int[]{cA, cA, cB, cB},
                    -hw, yA, zA,
                    hw, yA, zA,
                    hw, yB, zB,
                    -hw, yB, zB);
        }
    }

    private static float capeZ(float t, float age, float lift) {
        return t * t * lift + (float) Math.sin(age * 0.12f + t * 4.0f) * 0.02f * t;
    }

    // ---- wings ------------------------------------------------------------

    private static void wings(VertexConsumer vc, Matrix4f m, float age, int main, int bright) {
        float flap = 0.30f + 0.22f * (float) Math.sin(age * 0.18f);
        float[] phiDeg = {-75f, -55f, -35f, -15f, 5f, 22f};
        float[] lens = {0.50f, 0.68f, 0.82f, 0.88f, 0.78f, 0.60f};
        int baseCol = withAlpha(main, 235);
        int tipCol = withAlpha(bright, 200);
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < phiDeg.length; i++) {
                feather(vc, m, side * 0.10f, 0.10f, 0.18f, side,
                        (float) Math.toRadians(phiDeg[i]), lens[i], flap, baseCol, tipCol);
            }
        }
    }

    private static void feather(VertexConsumer vc, Matrix4f m, float bx, float by, float bz,
                                int side, float phi, float len, float flap, int cBase, int cTip) {
        float dx = (float) Math.cos(phi);
        float dy = (float) Math.sin(phi);
        float px = -dy, py = dx;
        float w = 0.045f;

        float[][] pts = {
                {px * w, py * w},
                {-px * w, -py * w},
                {dx * len - px * w * 0.4f, dy * len - py * w * 0.4f},
                {dx * len + px * w * 0.4f, dy * len + py * w * 0.4f}
        };

        float cf = (float) Math.cos(flap);
        float sf = (float) Math.sin(flap);
        float[] v = new float[12];
        for (int i = 0; i < 4; i++) {
            float om = pts[i][0];
            v[i * 3] = bx + side * om * cf;
            v[i * 3 + 1] = by + pts[i][1];
            v[i * 3 + 2] = bz + om * sf;
        }
        quad(vc, m, new int[]{cBase, cBase, cTip, cTip},
                v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11]);
    }

    // ---- helpers ----------------------------------------------------------

    /** Emits a quad twice (front and back) so it is visible from both sides. */
    private static void quad(VertexConsumer vc, Matrix4f m, int[] c, float... p) {
        for (int i = 0; i < 4; i++) vertex(vc, m, p[i * 3], p[i * 3 + 1], p[i * 3 + 2], c[i]);
        for (int i = 3; i >= 0; i--) vertex(vc, m, p[i * 3], p[i * 3 + 1], p[i * 3 + 2], c[i]);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, float x, float y, float z, int argb) {
        vc.addVertex(m, x, y, z).setColor((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, (argb >>> 24) & 255);
    }

    private static int withAlpha(int rgb, int a) {
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
