package com.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;

@EventBusSubscriber(modid = FlrVisuals.MODID, value = Dist.CLIENT)
public final class GameEvents {
    private GameEvents() {}

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();

        while (FlrKeys.MENU.consumeClick()) {
            if (mc.screen == null) {
                mc.setScreen(new CosmeticsScreen());
            }
        }

        LocalPlayer p = mc.player;
        ClientLevel level = mc.level;
        if (p == null || level == null || mc.isPaused()) return;

        long time = level.getGameTime();

        // Aura: two glowing points orbiting the body, rising in a helix.
        if (Config.aura && time % 2 == 0) {
            double base = time * 0.2;
            double y = p.getY() + 0.1 + ((time % 30) / 30.0) * p.getBbHeight();
            for (int i = 0; i < 2; i++) {
                double a = base + i * Math.PI;
                level.addParticle(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(a) * 0.55, y, p.getZ() + Math.sin(a) * 0.55,
                        0.0, 0.01, 0.0);
            }
        }

        // Trail: sparks at the feet while moving.
        if (Config.trail && p.getDeltaMovement().horizontalDistanceSqr() > 0.003) {
            for (int i = 0; i < 2; i++) {
                level.addParticle(ParticleTypes.ELECTRIC_SPARK,
                        p.getX() + (level.random.nextDouble() - 0.5) * 0.5,
                        p.getY() + 0.1,
                        p.getZ() + (level.random.nextDouble() - 0.5) * 0.5,
                        0.0, 0.02, 0.0);
            }
        }
    }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        if (!Config.hitSparks) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || event.getEntity() != mc.player) return;

        Entity target = event.getTarget();
        double cy = target.getY() + target.getBbHeight() * 0.5;
        for (int i = 0; i < 14; i++) {
            mc.level.addParticle(ParticleTypes.ELECTRIC_SPARK,
                    target.getX(), cy, target.getZ(),
                    (mc.level.random.nextDouble() - 0.5) * 0.5,
                    (mc.level.random.nextDouble() - 0.2) * 0.4,
                    (mc.level.random.nextDouble() - 0.5) * 0.5);
        }
    }
}
