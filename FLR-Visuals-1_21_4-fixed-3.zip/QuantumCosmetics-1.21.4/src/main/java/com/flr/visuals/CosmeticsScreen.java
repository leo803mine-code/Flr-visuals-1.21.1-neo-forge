package com.flr.visuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class CosmeticsScreen extends Screen {
    private static final ResourceLocation LOGO =
            ResourceLocation.fromNamespaceAndPath("flrvisuals", "textures/gui/logo.png");

    private static final int PANEL_W = 300;
    private static final int PANEL_H = 256;

    public CosmeticsScreen() {
        super(Component.literal("FLR Visuals"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 115;
        int right = this.width / 2 + 5;
        int y = (this.height - PANEL_H) / 2 + 84;

        addRenderableWidget(toggle("Halo", () -> Config.halo, v -> Config.halo = v, left, y, 110));
        addRenderableWidget(toggle("Wings", () -> Config.wings, v -> Config.wings = v, right, y, 110));
        y += 24;
        addRenderableWidget(toggle("Cape", () -> Config.cape, v -> Config.cape = v, left, y, 110));
        addRenderableWidget(toggle("Aura", () -> Config.aura, v -> Config.aura = v, right, y, 110));
        y += 24;
        addRenderableWidget(toggle("Trail", () -> Config.trail, v -> Config.trail = v, left, y, 110));
        addRenderableWidget(toggle("Hit Sparks", () -> Config.hitSparks, v -> Config.hitSparks = v, right, y, 110));
        y += 24;

        addRenderableWidget(Button.builder(colorLabel(), b -> {
            Config.theme = (Config.theme + 1) % Config.THEME_COLORS.length;
            b.setMessage(colorLabel());
        }).bounds(left, y, 230, 20).build());
        y += 28;

        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left, y, 230, 20).build());
    }

    private static Component colorLabel() {
        return Component.literal("Color: " + Config.THEME_NAMES[Config.theme]);
    }

    private static Button toggle(String name, BooleanSupplier state, Consumer<Boolean> setter,
                                 int x, int y, int w) {
        return Button.builder(label(name, state.getAsBoolean()), b -> {
            boolean now = !state.getAsBoolean();
            setter.accept(now);
            b.setMessage(label(name, now));
        }).bounds(x, y, w, 20).build();
    }

    private static Component label(String name, boolean on) {
        return Component.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (FlrKeys.MENU.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);

        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;

        g.fill(x, y, x + PANEL_W, y + PANEL_H, 0xF20A0A0F);
        g.fill(x + 1, y + 1, x + PANEL_W - 1, y + 2, 0xFF7A5CFF);
        g.renderOutline(x, y, PANEL_W, PANEL_H, 0xFF292332);

        g.blit(LOGO, x + 16, y + 14, 0, 0, 56, 56, 56, 56);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);

        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;

        g.drawString(this.font, "FLR VISUALS", x + 84, y + 24, 0xFFFFFFFF);
        g.drawString(this.font, "1.21.1  \u2022  NEOFORGE", x + 84, y + 40, 0xFF8D8499);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
