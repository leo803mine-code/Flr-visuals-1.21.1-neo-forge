package com.flr.visuals;

public final class Config {
    public static boolean halo = true;
    public static boolean wings = true;
    public static boolean cape = true;
    public static boolean aura = true;
    public static boolean trail = true;
    public static boolean hitSparks = true;
    public static int theme = 0;

    public static final String[] THEME_NAMES = {"Purple", "Cyan", "Pink", "Gold", "Green"};
    public static final int[] THEME_COLORS = {0x7A5CFF, 0x2ED9FF, 0xFF4DA6, 0xFFC83D, 0x39E079};

    private Config() {}

    public static int color() {
        return THEME_COLORS[theme % THEME_COLORS.length];
    }
}
