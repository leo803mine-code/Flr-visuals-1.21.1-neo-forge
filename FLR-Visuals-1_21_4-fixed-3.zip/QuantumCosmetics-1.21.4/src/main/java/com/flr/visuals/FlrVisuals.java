package com.flr.visuals;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;

@Mod(value = FlrVisuals.MODID, dist = Dist.CLIENT)
public class FlrVisuals {
    public static final String MODID = "flrvisuals";

    public FlrVisuals() {
    }
}
