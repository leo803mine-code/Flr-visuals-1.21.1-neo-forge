package com.flr.visuals;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class FlrKeys {
    public static final KeyMapping MENU = new KeyMapping(
            "key.flrvisuals.menu", InputConstants.Type.KEYSYM,
            InputConstants.KEY_RSHIFT, "key.categories.flrvisuals");

    private FlrKeys() {}
}
